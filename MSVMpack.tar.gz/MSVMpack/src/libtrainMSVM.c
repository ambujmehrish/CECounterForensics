/* Copyright 2008-2010 Yann Guermeur                                        */

/* This program is free software; you can redistribute it and/or modify     */
/* it under the terms of the GNU General Public License as published by     */
/* the Free Software Foundation; either version 2 of the License, or        */
/* (at your option) any later version.                                      */

/* This program is distributed in the hope that it will be useful,          */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/* GNU General Public License for more details.                             */

/* You should have received a copy of the GNU General Public License        */
/* along with this program; if not, write to the Free Software              */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA*/

/*--------------------------------------------------------------------------*/
/*  Name           : libtrainMSVM.c                                         */
/*  Version        : 2.0                                                    */
/*  Creation       : 06/20/08                                               */
/*  Last update    : 02/04/11                                               */
/*  Subject        : Training functions for MSVMpack                        */
/*  Algo.          : Wrapper functions only                                 */
/*  Author         : Fabien Lauer and Yann Guermeur fabien.lauer@loria.fr  */
/*--------------------------------------------------------------------------*/

#include "libtrainMSVM.h"
#include "libtrainMSVM_WW.h"
#include "libtrainMSVM_CS.h"
#include "libtrainMSVM_LLW.h"
#include "libtrainMSVM_2.h"
#include "libtrainMSVM_2fw.h"

/*
	status = MSVM_train(model, training_set, chunk_size, accuracy, cache_size_in_mb, alpha0_file, alpha_file, log_file)
	
		use accuracy = 0 	for infinite training 
		use alpha0_file = NULL 	for default initialization of alpha
		use alpha_file = NULL 	to deactivate periodic saving of alpha
		use log_file = NULL 	to deactivate optimization log
		
	Return value:
		-1	: Error (infeasible initial alpha or unknown model type)
		0 	: Optimum found with desired accuracy level
		1	: Stopped after maximum number of iterations
		N > 1	: Stopped by user after N iterations
		
*/

long MSVM_train(struct Model *model, struct Data *training_set, long chunk_size, const double accuracy, int cache_memory, char *alpha0_file, char *alpha_file, char *log_file)
{
	long return_status;	
	switch (model->type) {
		case WW:
			return_status = MSVM_WW_train(model,training_set,chunk_size,accuracy, 							cache_memory, alpha0_file,alpha_file,log_file);
			break;
		
		case CS:
			return_status = MSVM_CS_train(model,training_set,chunk_size,accuracy, 							cache_memory, alpha0_file,alpha_file,log_file);
					
			break;
		
		case LLW:
			return_status = MSVM_LLW_train(model,training_set,chunk_size,accuracy,
						cache_memory, alpha0_file,alpha_file,log_file);
			break;
		
		case MSVM2:
			if(model->algorithm == Rosen) {
				printf("Starting Rosen's algorithm to train an M-SVM^2...\n");
				return_status = MSVM_2_train(model,training_set,chunk_size,accuracy,
						cache_memory, alpha0_file,alpha_file,log_file);
			}
			else
				return_status = MSVM_2fw_train(model,training_set,chunk_size,accuracy,
						cache_memory, alpha0_file,alpha_file,log_file);
			break;
				
		default:
			printf("MSVM_train: Unknown model type. \n");
			return_status = -1;
			break;
	
	}
	return return_status;
}


/* 
	Initializes the parameters and filenames used for training an M-SVM 
    	from a .com file.
*/
long MSVM_init_train_comfile(struct Model *model, char *com_file, char *training_file, char *alpha0_file, char *alpha_file, char *log_file) {

	long chunk_size;
	unsigned int kernel_type;
	FILE *fs;
	long nr = 0;
	
	if((fs=fopen(com_file, "r"))==NULL)
	  {
	  printf("\n.com file %s cannot be open.\n", com_file);
	  exit(0);
	  }

	nr += fscanf(fs, "%ld", &(model->Q));
	nr += fscanf(fs, "%d", &kernel_type);
	model->nature_kernel = kernel_type;
	set_default_kernel_par(model);
	
	nr += fscanf(fs, "%lf", &(model->C));
	nr += fscanf(fs, "%ld", &chunk_size);
	nr += fscanf(fs, "%s", training_file);
	printf("\nThe file of the training data is: %s", training_file);
	nr += fscanf(fs, "%s", alpha0_file);
	nr += fscanf(fs, "%s", alpha_file);
	nr += fscanf(fs, "%s", log_file);	
	
	fclose(fs);
	if(nr < 5) 
		printf("\nError in reading com file %s, not enough data.\n", com_file);
	return chunk_size;
}

/*
	init_alpha_b(model_ptr, alpha_file)
	
	Initialize the alpha of the model pointed by model_ptr by
		reading them from the file alpha_file or 
		setting all alpha to 0 if alpha_file is NULL
		
	Also (re)allocate memory for the vector b 
*/
void init_alpha_b(struct Model *model, char *alpha_file) {
	long i,k;
	const long Q = model->Q;
	const long nb_data = model->nb_data;

	if(model->type == CS) {
		printf("Do not use init_alpha_b() with CS-type M-SVM:\n This M-SVM has no vector b and cannot initalize all alpha to 0.\n Use CS_init_alpha() instead.\n");
		exit(0);
	}
		
	// Initialize alpha
	if(alpha_file == NULL) {
		if (model->alpha != NULL) {
			free(model->alpha[1]); free(model->alpha);
		}
		model->alpha = matrix(nb_data, Q);
		model->partial_average_alpha = (double *) realloc(model->partial_average_alpha, sizeof(double) * (nb_data+1));	
		
		for(i=1; i<=nb_data; i++) {
		  model->partial_average_alpha[i] = 0.0;
		  for(k=1; k<=Q; k++)
		    model->alpha[i][k] = 0.0;
		}
		model->sum_all_alpha = 0.0;	
	}
	else
		read_alpha(model, alpha_file);
	
	// Initialize b
	model->b_SVM = (double *)realloc(model->b_SVM, (Q+1) *  sizeof(double));
		
	return;
}


/* 
	compute_K(cache,model)

	Compute the submatrix of the Kernel matrix corresponding to the chunk 
*/
void compute_K(struct TrainingCache *cache, const struct Model *model)
{
	long i;	
	const long chunk_size = cache->chunk_size;
		
	for(i=1; i<=chunk_size; i++) {
	  cache->K[i] = kernel_get_row(cache->table_chunk[i], cache->kc, model);
	}

}
/*
	Release the cache space reserved for the kernel submatrix corresponding to the chunk
*/
void release_K(struct TrainingCache *cache) {
	long i;
	const long chunk_size = cache->chunk_size;
	
	// Take mutex on in_use 
	pthread_mutex_lock(&kernelcache_inuse_mutex);
		
	for (i=1;i<=chunk_size;i++) {
		cache->kc->in_use[cache->kc->rows_idx[cache->table_chunk[i]]]--;		
	}
	// Release mutex on in_use
	pthread_mutex_unlock(&kernelcache_inuse_mutex);

}


void kernel_initialize_cache(unsigned long cache_size, struct KernelCache *kc, const struct Model *model) {
	
	long nb_data = model->nb_data;
	long i;
	
	unsigned long size_row = sizeof(double) * (nb_data + 1);	// Size of a kernel row
	unsigned long size_max = (size_row + 1) * (nb_data + 1); // Maximal necessary cache size
	
	if(cache_size < size_row)
		cache_size = 0;
		
	// Allign cache_size with size_row
	if(cache_size % size_row > 0)
		cache_size -= cache_size % size_row;
	
	// Limit cache_size to what is necessary
	if(cache_size > size_max)
		cache_size = size_max;
		
	// Allocate maximal cache memory
	kc->K = NULL;
	while (kc->K == NULL && cache_size>0) {
		kc->K = (double *)malloc(cache_size);
		if(kc->K == NULL) 
			cache_size -= size_row;
	}
	if(kc->K == NULL) {
		printf("no more memory, abording.\n");
		exit(1);
	}
	
	// How many rows allocated?
	long nrows = (cache_size/size_row) - 1; 
	
	// Pointers to rows 
	kc->rows_ptr = (double **)malloc(sizeof(double *) * (nrows + 1));
	for (i=0;i<=nrows;i++) {
		kc->rows_ptr[i] = NULL;	// NULL means row not available;
	}
	// Which cache_index for these rows?
	kc->rows_idx = (long *)calloc(nb_data+1, sizeof(long));
	kc->rows_idx_inv = (long *)calloc(nrows+1, sizeof(long));
	
	// Which rows are in use (and by how many threads)?
	kc->in_use = (int *)calloc(nrows+1, sizeof(int));
	
	if(kc->in_use == NULL) {
		printf("initializing kernel cache: not enough memory.\n");
		exit(1);
	}
	else {
		printf("Allocated %lu MB of memory to cache %ld rows (%ld %%) of the kernel matrix.\n",cache_size/MBYTES + 1, nrows,100 * nrows/nb_data);
	}
	
	kc->nrows = nrows;
	kc->max_idx = 1;	// first free row index
	kc->is_full = 0;
	
	// Initialize mutexes and condition variables
	kernelcache_rowptr_mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t) * (nrows+1));
	kernelcache_rowptr_cond = (pthread_cond_t *)malloc(sizeof(pthread_cond_t) * (nrows+1));	
	for(i=1;i<=nrows;i++) {
		pthread_mutex_init(&kernelcache_rowptr_mutex[i], NULL);
		pthread_cond_init (&kernelcache_rowptr_cond[i], NULL);
	}
	return ;
}

void kernel_free_cache(struct KernelCache *kc) {
	free(kc->K);
	free(kc->rows_ptr);
	free(kc->rows_idx);
	free(kc->rows_idx_inv);	
	free(kc->in_use);
	long i;
	for(i=1;i<=kc->nrows;i++) {
		pthread_mutex_destroy(&kernelcache_rowptr_mutex[i]);
		pthread_cond_destroy (&kernelcache_rowptr_cond[i]);
	}
	free(kernelcache_rowptr_mutex);
	free(kernelcache_rowptr_cond);
}

/*
	Fetch a pointer to the row in cache corresponding to X_index
*/
double *kernel_get_row(long index, struct KernelCache *kc, const struct Model *model) {
	long i=0;
	
	// Make sure no other thread modifies the in_use table during this check
	pthread_mutex_lock(&kernelcache_inuse_mutex);
	
	// is the row already available?
	if(kc->rows_idx[index] != 0  && kc->rows_ptr[kc->rows_idx[index]]  != NULL ) {
		
		// Yes, so mark it as "in use"
		kc->in_use[kc->rows_idx[index]]++;
		pthread_mutex_unlock(&kernelcache_inuse_mutex);
	
		// and return pointer to row data
		return kc->rows_ptr[kc->rows_idx[index]];
	}
	else if (kc->rows_idx[index] != 0  && kc->rows_ptr[kc->rows_idx[index]] == NULL) {
		// The row is being computed by another thread,
		// so wait for it to be ready
		pthread_mutex_unlock(&kernelcache_inuse_mutex); // do not block other threads while waiting
		
		pthread_mutex_lock(&kernelcache_rowptr_mutex[kc->rows_idx[index]]);	
		if(kc->rows_ptr[kc->rows_idx[index]] == NULL) {
			pthread_cond_wait(&kernelcache_rowptr_cond[kc->rows_idx[index]], &kernelcache_rowptr_mutex[kc->rows_idx[index]]);
		}
		pthread_mutex_unlock(&kernelcache_rowptr_mutex[kc->rows_idx[index]]);
		
		if(kc->rows_ptr[kc->rows_idx[index]] != NULL) {
			// update in_use			
			pthread_mutex_lock(&kernelcache_inuse_mutex);
			kc->in_use[kc->rows_idx[index]]++;
			pthread_mutex_unlock(&kernelcache_inuse_mutex);
			// and return pointer to the computed row in cache
			return kc->rows_ptr[kc->rows_idx[index]];
		}
		else {
			printf("Error in kernel_get_row: row not really available.\n");
			exit(1);
		}
	}
	
	// Row is not currently available, so compute kernel row
	if(kc->is_full) {
		// Cache already full, so search for the first row not currently in use
		i = 1;	
		while(i<=kc->nrows && kc->in_use[i] > 0) {
			i++;
		}
		if(i > kc->nrows) {
			printf("Not enough memory for kernel caching. Reduce the number of CPUs or increase kernel cache memory.\n");
			exit(0);
		}		
	}
	else {
		// Append row at the end of cache
		i = kc->max_idx;
		kc->max_idx++;
		if(kc->max_idx > kc->nrows){
			kc->is_full = 1;			
		}
	}
	
	kc->in_use[i]++;		// Mark row as in use
	kc->rows_ptr[i] = NULL;		// but as not available (going to overwrite it)	
	kc->rows_idx[index] = i;	// and currently computing
	kc->rows_idx[kc->rows_idx_inv[i]] = 0;	// mark previously cached row as unavailable

	// Release mutex on in_use
	pthread_mutex_unlock(&kernelcache_inuse_mutex);
	
	// Compute and cache the kernel row for X_index at location i in the kernel cache
	compute_kernel_row(index, i, kc, model);		// do the computation

	pthread_mutex_lock(&kernelcache_rowptr_mutex[i]);	// 
	pthread_cond_broadcast(&kernelcache_rowptr_cond[i]);	// signal that the row is ready
	pthread_mutex_unlock(&kernelcache_rowptr_mutex[i]);	// and unlock other waiting threads

	// Return the row_ptr to the row just computed
	return kc->rows_ptr[i];		

} 

void compute_kernel_row(const long index, const long cache_index, struct KernelCache *kc, const struct Model *model) {
	const long nb_data = model->nb_data;
	const long nature_kernel = model->nature_kernel;
	const long dim_input = model->dim_input;
	const double *kernel_par = model->kernel_par;
	double *row_ptr = &(kc->K[(cache_index-1)*(nb_data+1)]); // base address of row in cache memory
	long j;
	double *k = row_ptr + 1;

	// Compute row
	for(j=1; j<=nb_data; j++) {
	 	*k++ = ker(nature_kernel, model->X[index], model->X[j], dim_input, kernel_par);	 		
	}
	
	if(model->type == MSVM2)
	  	row_ptr[index] += 1. /(2 * model->C);

	// Mark row as available 	
	kc->rows_idx_inv[cache_index] = index;
	kc->rows_ptr[cache_index] = row_ptr;
}


/*
	Switch working load between threads 
	from main (kernel) computations to gradient updates
	
	As as result, the number of threads used for gradient updates increases
	while main computing threads (XX_train_thread) are terminated

	returns 1 if the calling main thread must stop 
*/
int __inline__ switch_thread(int *numthreads_grad, int *next_numthreads_grad, long *percentage, int *percentage_step, struct ThreadGradient_data *grad_data, int thread_id, long nb_data) {	

	int k;

	// Keep (NUMTHREADS - next_numthreads_grad + 1) main computing threads
	// for kernel evaluations	
	if(thread_id < NUMTHREADS - *next_numthreads_grad + 1){
	
		// This calling thread continues with more children to compute gradient updates
		*numthreads_grad = *next_numthreads_grad;

		// Update splits of the gradient vector
		grad_data[0].start_i = 1;
		grad_data[0].end_i = nb_data / *numthreads_grad;	
		for(k=1;k<*numthreads_grad-1;k++) {	
			grad_data[k].start_i = grad_data[k-1].end_i + 1;
			grad_data[k].end_i = grad_data[k].start_i + nb_data / *numthreads_grad -1;
		}
		if(*numthreads_grad>1) {
			grad_data[*numthreads_grad-1].start_i = grad_data[*numthreads_grad-2].end_i + 1;
			grad_data[*numthreads_grad-1].end_i = nb_data;
		}
		
		// Update percentage for next step
		switch(*percentage_step) {
		case 1:
			*percentage =  nb_data / 2; 		// 50% of kernel matrix
			*next_numthreads_grad = NUMTHREADS/2;	// -> 50% of CPUs for gradient
			break;
		case 2:
			*percentage = 3 * nb_data / 4; 		// 75%
			*next_numthreads_grad = 3*NUMTHREADS/4;	// -> 3/4 of CPUs
			break;
		case 3:
			*percentage = 19 * nb_data / 20; 	// 95%
			*next_numthreads_grad = NUMTHREADS-1;	// -> all CPUs - 1
			break;
		case 4:
			*percentage = nb_data;			// 100% (entire kernel matrix in memory)
			*next_numthreads_grad = NUMTHREADS;	// -> all CPUs for gradient updates
			break;
		default:
			*percentage = 2*nb_data; // no more steps
			break;
		}
		if(*next_numthreads_grad == 0)
			*next_numthreads_grad = 1;
			
		*percentage_step += 1;
		return 0;
	}

	else {
		// The calling thread must stop (enough kernel rows have been computed)
		
		//printf("%ld rows of kernel matrix cached, stopping thread %d... \n",percentage,thread_id);
		return 1;
	}

}

/*
	Randomly select a chunk of data (working set)
	
	At each training step, only the variables alpha_ik 
	corresponding to this chunk are optimized. 
*/
void select_random_chunk(struct TrainingCache *cache, const struct Model *model)
{
	long i,j,random_num,row;
	const long nb_data = model->nb_data;
	const long chunk_size = cache->chunk_size;
	
	for(i=1; i<=nb_data; i++)
	  {
	  cache->out_of_chunk[i] = i;
	  cache->in_chunk[i] = 0;	  
	  }
	  
	for(i=1; i<=chunk_size; i++)
	  {
	  random_num = nrand48(xi);
	  row = (random_num % (nb_data-i+1))+1;
	  cache->table_chunk[i] = cache->out_of_chunk[row];
	  for(j=row; j<=nb_data-i; j++)
	    cache->out_of_chunk[j] = cache->out_of_chunk[j+1];
	  cache->in_chunk[cache->table_chunk[i]] = 1;
	  }
	  
	  return;
}


/* 
	Write a vector/matrix to a file (used for the vector alpha) 
*/
void write_vector(double **vector, const long nb_data, const long Q, char *file)

{
	long i,k;
	FILE *fc;
	int rc;
	 
	char command[taille];
	
	if((fc=fopen(file, "w"))==NULL)
	  {
	  printf("\nThe file %s cannot be open.\n", file);
	  exit(0);
	  }

	for(i=1; i<=nb_data; i++)
	  for(k=1; k<=Q; k++)
	    fprintf(fc, "%15.10f %c", vector[i][k], (k==Q) ? '\n': ' ');

	fclose(fc);
	 
	sprintf(command, "cp %s Save_alpha/.", file);
	rc = system(command);
}

/*
	Print info during training
*/
void print_training_info(const long iter, const long nb_SV, const double ratio, const enum MSVM_type type) {
	char iter_str[20], nb_SV_str[20];
	int i,num_spaces;
	
	if(iter == 0)  {
		if(type == MSVM2)
			printf("\n Iteration\t Number of Support Vectors\t Ratio dual/primal\n");
		else
			printf("\n Iteration\t Number of margin Sup. Vec.\t Ratio dual/primal\n");
		printf("-------------------------------------------------------------------\n");
	} 
		
	sprintf(iter_str, "%ld",iter);
	num_spaces = (TRAIN_STEP/TRAIN_SMALL_STEP) - strlen(iter_str) - 1;
	for(i=0;i<num_spaces;i++)
		strcat(iter_str," "); 
		
	if(strlen(iter_str) < 7)
		strcat(iter_str, "\t\t");
	else if (strlen(iter_str) < 15)
		strcat(iter_str, "\t");

	sprintf(nb_SV_str, "%ld",nb_SV);
	if(strlen(nb_SV_str) < 5)
		sprintf(nb_SV_str, " %ld\t\t\t\t",nb_SV);
	else if (strlen(nb_SV_str) < 13)
		sprintf(nb_SV_str, " %ld\t\t\t",nb_SV);

	if(ratio == 0 || ratio == 1.0)
		printf("\r %s  %s  %1.0lf %%\n",iter_str, nb_SV_str, 100*ratio);
	else if(ratio < 0.995 && ratio > 0.0001)
		printf("\r %s  %s  %3.2lf %%\n",iter_str, nb_SV_str, 100*ratio);
	else if(ratio < 0.999999 && ratio > 0.000001)
		printf("\r %s  %s  %3.4lf %%\n",iter_str, nb_SV_str, 100*ratio);
	else
		printf("\r %s  %s  %3.8lf %%\n",iter_str, nb_SV_str, 100*ratio);
}

