#include "libMSVM.h"        // Generic structure and function declarations
#include "libtrainMSVM.h"   // Training functions (not required for predictions only)
#include "libevalMSVM.h"    // Evaluation functions (also used during training)

int main(void) {
    struct Model *model;                    // declare a model
    struct Data *training_set, *test_set;   // declare the datasets
    
    long status;                // for MSVM_train return code
    double accuracy = 0.98;     // desired accuracy level of 98%  
    long chunk_size = 4;        // size of the chunk used for training
    int cache_memory = 1024;    // Maximal amount of cache memory in MB
    long *labels;
    
    printf("This is a simple example showing how to use\n MSVMpack through the C API.\n\n");
            
    model = MSVM_make_model(MSVM2); // Create an empty model with default parameters
    if(model == NULL) {
        printf("Error in model creation\n");
        exit(1);
    }
    else 
        printf("M-SVM model successfully created with defaults:\n MSVM2-type, C = %1.2lf, kernel type = %d.\n", model->C, model->nature_kernel);

    // Change some parameters
    model->nature_kernel = RBF;    
    printf("Changed the kernel type in model to Gaussian RBF\n");
    model->C = 1.0;
    printf("Changed hyperparameter C to %1.2lf\n",model->C);

    printf("Loading the data... \n ");
    // The data format can be either DOUBLE, FLOAT, INT, SHORT, BYTE, or BIT
    training_set = MSVM_make_dataset("myTrainingData",DOUBLE); // load the training data
    test_set = MSVM_make_dataset("myTestData",DOUBLE);         // load the test data
        
    /* Train the model on the training_set
        with default initialization (first NULL)
        no periodic saving of alpha (second NULL)
        no log file (third NULL)
    */
    status = MSVM_train(model, training_set, chunk_size, accuracy, cache_memory, NULL, NULL, NULL);
        
    if(status >= 0) {
        printf("Training done without error, will now classify the test set.\n");

	/* Allocate the array for predicted labels 
		(size should be (size of test set + 1) )
	*/
        labels = (long *)malloc(sizeof(long) * (test_set->nb_data + 1));

        /* Classify the test set,
        	store the predicted labels in 'labels'
        	and print outputs on screen (filename=NULL)
        */ 
        MSVM_classify_set(labels, test_set->X, test_set->y, test_set->nb_data, NULL, model);
    }
    else
        printf("Error in training.\n");
        
    // Free the memory
    free(labels);
    MSVM_delete_model(model);    
    MSVM_delete_dataset(training_set);
    MSVM_delete_dataset(test_set);

    return 0;
}

