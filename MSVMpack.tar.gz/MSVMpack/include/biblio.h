void display_stats(long classes, long **matrice);
void display_full_stats(long classes, long **matrice);
